package com.lms.business.models;

import lombok.Getter;

@Getter
public class NotificationRequest {
    private String message;
}
