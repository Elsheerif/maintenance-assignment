package com.lms.persistence;

public enum OtpStatus {

    DELIVERED,FAILED
}
