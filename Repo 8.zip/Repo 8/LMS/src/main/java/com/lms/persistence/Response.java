package com.lms.persistence;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Response {

	private boolean status;
	private String message;

}
