package com.lms;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class LMSResponse {

  public int code;
  public String body;
}
